import java.util.Arrays;
public class HomeWork2 {
    public static void main(String[] args) {
        int[] A ={1, 2, 3, 4, 5, 6, 7};
        int[] B=A;
        System.out.println(Arrays.toString(B));
    }
}
