public class Ex2 {
    public static void main(String[] args) {
        int num=1;
        while (num<=10)
        {
            System.out.println(num);
            num++;
        }
    }
}
