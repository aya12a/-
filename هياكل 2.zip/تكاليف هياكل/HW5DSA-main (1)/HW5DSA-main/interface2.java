public interface interface2 {

}
