//public class Q3_1 {
//     /∗∗ Tests if delimiters in the given expression are properly matched. ∗/
//
